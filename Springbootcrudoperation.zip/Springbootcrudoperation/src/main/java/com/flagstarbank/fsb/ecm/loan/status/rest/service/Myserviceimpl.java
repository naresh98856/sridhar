package com.flagstarbank.fsb.ecm.loan.status.rest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flagstarbank.fsb.ecm.loan.status.rest.dao.MyEventdaorepository;
import com.flagstarbank.fsb.ecm.loan.status.rest.dao.Mydaorepository;
import com.flagstarbank.fsb.ecm.loan.status.rest.model.Employee;
import com.flagstarbank.fsb.ecm.loan.status.rest.model.VWFSBKOFAXFILENET;

@Service
public class Myserviceimpl implements Myservice {

	@Autowired
	Mydaorepository dao;
	
	@Autowired
	MyEventdaorepository myEventdaorepository;

	@Override
	public List<Employee> getEmployees() {
		return dao.findAll();
	}
	@Override
	public Optional<VWFSBKOFAXFILENET> getEmployeeById(String empid) {
		Optional<VWFSBKOFAXFILENET> event=myEventdaorepository.findById(empid);
		System.out.println("The data object  thhhh------>"+event.get());
		if(event.get().getIUC_FLAG()=="N" && event.get().getUW_READY_FLAG()=="Y")
			System.out.println("soap call 1");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="Y" && event.get().getCONDITION_TYPE()=="U")
			System.out.println("soap call 2");
		else if(event.get().getIUC_FLAG()=="N" && event.get().getUW_READY_FLAG()=="N")
			System.out.println("soap call 3");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="N" && event.get().getCONDITION_TYPE()=="U")
			System.out.println("soap call 4");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="Y" && event.get().getCONDITION_TYPE()=="P")
			System.out.println("soap call 5");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="N" && event.get().getCONDITION_TYPE()=="P")
			System.out.println("soap call 6");
		return event;
	}
	@Override
	public Employee addNewEmployee(Employee emp) {
		return dao.save(emp);
	}
	@Override
	public Employee updateEmployee(Employee emp) {
		return dao.save(emp);
	}
	@Override
	public void deleteEmployeeById(int empid) {
		dao.deleteById(empid);
	}
	@Override
	public void deleteAllEmployees() {
		dao.deleteAll();
	}
}
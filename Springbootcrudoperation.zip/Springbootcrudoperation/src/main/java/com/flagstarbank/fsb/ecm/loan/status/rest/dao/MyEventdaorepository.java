package com.flagstarbank.fsb.ecm.loan.status.rest.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.flagstarbank.fsb.ecm.loan.status.rest.model.VWFSBKOFAXFILENET;

public interface MyEventdaorepository extends JpaRepository<VWFSBKOFAXFILENET,String>{
	
	

}

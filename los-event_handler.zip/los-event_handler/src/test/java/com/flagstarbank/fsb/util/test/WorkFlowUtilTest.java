
package com.flagstarbank.fsb.util.test;

import static org.junit.Assert.assertEquals;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.ResourceUtils;
import org.springframework.web.context.WebApplicationContext;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.flagstarbank.fsb.util.WorkFlowUtil;


@RunWith(SpringRunner.class)
@WebMvcTest(WorkFlowUtil.class)
public class WorkFlowUtilTest {
	@Autowired
	private WebApplicationContext webApplicationContext;

	@Autowired
	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	@Test
	public void whenValidInputValues_ReadXmlForUtil()
	{
		try {
 	 File file = ResourceUtils.getFile("classpath:input.xml");
 		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(file);

		
doc.getDocumentElement().normalize();



NodeList nList = doc.getElementsByTagName("strXMLWorkitemData");

for (int temp = 0; temp < nList.getLength(); temp++) {

Node nNode = nList.item(temp);

	System.out.println("\nCurrent Element :" + nNode.getNodeName());
	if (nNode.getNodeType() == Node.ELEMENT_NODE) {

	Element eElement = (Element) nNode;
	assertEquals(eElement.getElementsByTagName("loan_num").item(0).getTextContent(),"602880724");
	assertEquals(eElement.getElementsByTagName("process_type").item(0).getTextContent(),"4506");
	assertEquals(eElement.getElementsByTagName("event").item(0).getTextContent(),"CONV");
    assertEquals(eElement.getElementsByTagName("entry_date").item(0).getTextContent(),"12/13/2018");
    assertEquals(eElement.getElementsByTagName("requesting_user").item(0).getTextContent(),"RBAGALKO");
	assertEquals(eElement.getElementsByTagName("unique_id").item(0).getTextContent(),"980011");
	assertEquals(eElement.getElementsByTagName("first_touched_user").item(0).getTextContent(),"RAJIV TESTER");
    assertEquals(eElement.getElementsByTagName("underwriter_name").item(0).getTextContent(),"UwShortName");

	}
	}
			
			    } catch (Exception e) {
			    	
			    	
}
}
}

package com.flagstarbank.fsb.client.tests;

import static org.junit.Assert.assertEquals;

import java.net.URISyntaxException;
import java.rmi.RemoteException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.flagstarbank.fsb.model.WorkItemValues;
import com.flagstarbank.fsb.updateservice.FSB_WorkflowLocatorClient;
import com.flagstarbank.fsb.updateservice.ServiceWrapper;

@RunWith(SpringRunner.class)
@WebMvcTest(FSB_WorkflowLocatorClient.class)
public class FSB_WorkflowLocatorClientTest {

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Autowired
	private MockMvc mockMvc;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
	}
	
	
	
	
	@Test
	public void whenValidValues_CallCmService() throws RemoteException, URISyntaxException
	{
		FSB_WorkflowLocatorClient fSB_WorkflowLocatorClient = new FSB_WorkflowLocatorClient();
		
		WorkItemValues workItemValues= new WorkItemValues();
		
		workItemValues.setLoan_num("602880724");
		workItemValues.setProcess_type("4506");
		workItemValues.setEvent("CONV");
		workItemValues.setEntry_date("12/13/2018");
		workItemValues.setRequesting_user("RBAGALKO");
		workItemValues.setUnique_id("980011");
		workItemValues.setFirst_touched_user("RAJIV TESTER");
		workItemValues.setUnderwriter_name("UwShortName");
		
		ResponseEntity<String> response = fSB_WorkflowLocatorClient.getDataResponse("602880724","4506","CONV","12/13/2018","RBAGALKO","980011","RAJIV TESTER","UwShortName");
		ServiceWrapper sw = new ServiceWrapper();
		String q  = sw.callUpdateService(workItemValues.getLoan_num(),workItemValues.getProcess_type(),workItemValues.getEvent(),
				workItemValues.getEntry_date(),workItemValues.getRequesting_user(),workItemValues.getUnique_id(),workItemValues.getFirst_touched_user(),
				workItemValues.getUnderwriter_name());
				
		assertEquals(200, response.getStatusCodeValue());
		String[] data = q.split(":");
		for (int i=0; i < data.length; i++)
		{
			
		assertEquals(data[0], "602880724");
		assertEquals(data[1],"4506");
		assertEquals(data[2],"CONV");
		assertEquals(data[3],"12/13/2018");
		assertEquals(data[4],"RBAGALKO");
		assertEquals(data[5],"980011");
		assertEquals(data[6],"RAJIV TESTER");
		assertEquals(data[7],"UwShortName");
		
		}
			
		}
	
	
}

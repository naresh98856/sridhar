package com.flagstarbank.fsb.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.flagstarbank.fsb.WorkFlowApplication;


@RunWith(SpringRunner.class)
@SpringBootTest
public class WorkFlowApplicationTest {

	@Test
	public void whenInitiated_StartApplication() {
		 WorkFlowApplication.main(new String[] {});
	}

}


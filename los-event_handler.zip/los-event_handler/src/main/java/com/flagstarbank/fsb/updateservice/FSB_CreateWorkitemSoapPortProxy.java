package com.flagstarbank.fsb.updateservice;

public class FSB_CreateWorkitemSoapPortProxy implements com.flagstarbank.fsb.updateservice.FSB_CreateWorkitemSoapPort {
  private String _endpoint = null;
  private com.flagstarbank.fsb.updateservice.FSB_CreateWorkitemSoapPort fSB_CreateWorkitemSoapPort = null;
  
  public FSB_CreateWorkitemSoapPortProxy() {
    _initFSB_CreateWorkitemSoapPortProxy();
  }
  
  public FSB_CreateWorkitemSoapPortProxy(String endpoint) {
    _endpoint = endpoint;
    _initFSB_CreateWorkitemSoapPortProxy();
  }
  
  private void _initFSB_CreateWorkitemSoapPortProxy() {
    try {
      fSB_CreateWorkitemSoapPort = (new com.flagstarbank.fsb.updateservice.FSB_WSDL_WorkflowLocator()).getFSB_CreateWorkitemSoapPort();
      if (fSB_CreateWorkitemSoapPort != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)fSB_CreateWorkitemSoapPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)fSB_CreateWorkitemSoapPort)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (fSB_CreateWorkitemSoapPort != null)
      ((javax.xml.rpc.Stub)fSB_CreateWorkitemSoapPort)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.flagstarbank.fsb.updateservice.FSB_CreateWorkitemSoapPort getFSB_CreateWorkitemSoapPort() {
    if (fSB_CreateWorkitemSoapPort == null)
      _initFSB_CreateWorkitemSoapPortProxy();
    return fSB_CreateWorkitemSoapPort;
  }
  
  public java.lang.String updateWebservice(javax.xml.rpc.holders.StringHolder strXMLWorkitemData) throws java.rmi.RemoteException{
    if (fSB_CreateWorkitemSoapPort == null)
      _initFSB_CreateWorkitemSoapPortProxy();
    return fSB_CreateWorkitemSoapPort.updateWebservice(strXMLWorkitemData);
  }
  
  
}
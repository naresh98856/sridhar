package com.flagstarbank.fsb.updateservice;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceWrapper {
	
	private static final Logger logger = LoggerFactory.getLogger(ServiceWrapper.class.getName());
	FSB_CreateWorkitemSoapBindingStub  stub;
	
	public ServiceWrapper(){

	try
	{
		FSB_WSDL_WorkflowLocator locator = new 							
				FSB_WSDL_WorkflowLocator();
		
		stub = (FSB_CreateWorkitemSoapBindingStub)locator.getFSB_CreateWorkitemSoapPort();
	}
	catch (ServiceException afe)
	{
		logger.info("Service Exception",afe);
		
	}
}

public String callUpdateService(String loanNum,String processType,String event,
		String entryDate,String requestingUser,String uniqueId,String firstTouchedUser,
		String underWriterName) throws RemoteException
{
	String requestBody="<WORKITEMVALUES>"
			+ "<loan_num>"+loanNum+"</loan_num>"
			+ "<process_type>"+processType+"</process_type>"
			+" <event>"+event+"</event>"
			+ "<entry_date>"+entryDate+"</entry_date>"
			+ "<requesting_user>"+requestingUser+"</requesting_user>"
			+ "<unique_id>"+uniqueId+"</unique_id>"
			+ "<first_touched_user>"+firstTouchedUser+"</first_touched_user>"
			+ "<underwriter_name>"+underWriterName+"</underwriter_name>"
			+ "</WORKITEMVALUES> ";
	
	javax.xml.rpc.holders.StringHolder strXMLWorkitemData=new javax.xml.rpc.holders.StringHolder();
	strXMLWorkitemData.value=requestBody;
	
	 String retVal = null;
	retVal =  stub.updateWebservice(strXMLWorkitemData);
	logger.info("The soap result->"+retVal);
	
	return retVal;
	
}

}
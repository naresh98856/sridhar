package com.flagstarbank.fsb.model;


public class WorkItemValues {

	
	private String requesting_user;
    private String unique_id;
    private String loan_num;
    private String underwriter_name;
    private String process_type;
    private String event;
    private String first_touched_user;
	private String entry_date;
    
  
	public String getRequesting_user() {
		return requesting_user;
	}

	public void setRequesting_user(String requesting_user) {
		this.requesting_user = requesting_user;
	}
	
	public String getUnique_id() {
		return unique_id;
	}
	
	public void setUnique_id(String unique_id) {
		this.unique_id = unique_id;
	}
	  
	public String getLoan_num() {
		return loan_num;
	}

	public void setLoan_num(String loan_num) {
		this.loan_num = loan_num;
	}
	  
	public String getUnderwriter_name() {
		return underwriter_name;
	}

	public void setUnderwriter_name(String underwriter_name) {
		this.underwriter_name = underwriter_name;
	}
	  
	public String getProcess_type() {
		return process_type;
	}

	public void setProcess_type(String process_type) {
		this.process_type = process_type;
	}
	  
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}
	  
	public String getFirst_touched_user() {
		return first_touched_user;
	}

	public void setFirst_touched_user(String first_touched_user) {
		this.first_touched_user = first_touched_user;
	}

	  
	public String getEntry_date() {
		return entry_date;
	}

	public void setEntry_date(String entry_date) {
		this.entry_date = entry_date;
	}
	
	
    
}

package com.flagstarbank.fsb.util;

import java.io.IOException;
import java.io.InputStream;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class WorkFlowUtil {
	
	public WorkFlowUtil()
	{
		
	}
	

	public String readXmlData() throws ParserConfigurationException, SAXException, IOException
	{
		 ClassLoader classLoader = getClass().getClassLoader();

	    InputStream inputStream = classLoader.getResourceAsStream("input.xml");

	           


		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		dbFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(inputStream);

				
		
		
		doc.getDocumentElement().normalize();

		System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
				
		
		return doc.getDocumentElement().getNodeName();
	}
}

/**
 * FSB_CreateWorkitemSoapPort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flagstarbank.fsb.updateservice;

public interface FSB_CreateWorkitemSoapPort extends java.rmi.Remote {
    public java.lang.String updateWebservice(javax.xml.rpc.holders.StringHolder strXMLWorkitemData) throws java.rmi.RemoteException;
}
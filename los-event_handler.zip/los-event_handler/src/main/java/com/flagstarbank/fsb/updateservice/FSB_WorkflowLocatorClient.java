package com.flagstarbank.fsb.updateservice;

import java.net.URI;
import java.net.URISyntaxException;
import java.rmi.RemoteException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.flagstarbank.fsb.model.WorkItemValues;
import com.flagstarbank.fsb.util.AppProperties;
public class FSB_WorkflowLocatorClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(FSB_WorkflowLocatorClient.class.getName());
	
	public ResponseEntity<String> getDataResponse(String loanNum,String processType,String event,
			String entryDate,String requestingUser,String uniqueId,String firstTouchedUser,
			String underWriterName) throws RemoteException, URISyntaxException
	{
		AppProperties ap = new AppProperties();		
		String env_dev=ap.fetchProperties().getProperty("env.dev");
		String env_prod=ap.fetchProperties().getProperty("env.prod");
		String env_test=ap.fetchProperties().getProperty("env.test");
		String env_stage=ap.fetchProperties().getProperty("env.stage");
		
		ServiceWrapper sw = new ServiceWrapper();
		String q  = sw.callUpdateService(loanNum,processType,event,entryDate,requestingUser,uniqueId,firstTouchedUser,underWriterName);
		
		
		ResponseEntity<String> responseObject;
		String[] data = q.split(":");
		for (int i=0; i < data.length; i++)
		{
			
	
			if(env_dev!= null)
			{
				responseObject = getUrlResponse(data[0],data[1],env_dev);
			
				
				return responseObject;
			}
		
			else if(env_stage!= null)
			{
			responseObject = getUrlResponse(data[0],data[1],env_stage);
			
				return responseObject;
			}
			
			else if(env_prod!= null)
			{
				responseObject = getUrlResponse(data[0],data[1],env_prod);
			
				return responseObject;
			}
			
			else if(env_test!= null)
			{
				responseObject = getUrlResponse(data[0],data[1],env_test);
			
				return responseObject;
			}
			
		}
		return null;
	}
	
	public ResponseEntity<String> getUrlResponse(String loan_num,String process_type,String url) throws URISyntaxException
	{
		
		
		RestTemplate restTemplate = new RestTemplate();
	   
	    WorkItemValues workItemValues = new WorkItemValues();
		

		
		workItemValues.setLoan_num(loan_num);
		workItemValues.setProcess_type(process_type);
		
		  final String baseUrl = url+loan_num+"/"+process_type;
		    URI uri = new URI(baseUrl);
		  
	     
	    HttpHeaders headers = new HttpHeaders();
	    headers.set("Authorization", "a33404e67a20b0bde29aea5a20324e966f0a58aeb0d295f57ffea17d71de5126");   
	       
	 
	    HttpEntity<WorkItemValues> request = new HttpEntity<>(workItemValues, headers);
	    
	    ResponseEntity<String> result = restTemplate.postForEntity(uri, request, String.class);
	    
		
		    return result;
	}

	}
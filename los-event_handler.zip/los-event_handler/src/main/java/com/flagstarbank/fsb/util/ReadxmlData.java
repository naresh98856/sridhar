package com.flagstarbank.fsb.util;

import java.io.File;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ResourceUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.flagstarbank.fsb.updateservice.FSB_WorkflowLocatorClient;

public class ReadxmlData {
	
	private static final Logger logger = LoggerFactory.getLogger(ReadxmlData.class.getName());
	
	public void readXml()
	{
		 try {
			 
			 File file = ResourceUtils.getFile("classpath:input.xml");
			 
				
				DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
				dbFactory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
				DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
				Document doc = dBuilder.parse(file);
						
		
				doc.getDocumentElement().normalize();

				System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
						
				NodeList nList = doc.getElementsByTagName("strXMLWorkitemData");
						
				
				FSB_WorkflowLocatorClient fSB_WorkflowLocatorClient = new FSB_WorkflowLocatorClient();
			
				for (int temp = 0; temp < nList.getLength(); temp++) {

					Node nNode = nList.item(temp);
							
					System.out.println("\nCurrent Element :" + nNode.getNodeName());
							
					if (nNode.getNodeType() == Node.ELEMENT_NODE) {

						Element eElement = (Element) nNode;
						
						logger.info(" loan_num: " + eElement.getElementsByTagName("loan_num").item(0).getTextContent());
						logger.info(" process_type " + eElement.getElementsByTagName("process_type").item(0).getTextContent());
						logger.info(" event " + eElement.getElementsByTagName("event").item(0).getTextContent());
						logger.info(" entry_date " + eElement.getElementsByTagName("entry_date").item(0).getTextContent());
						logger.info(" requesting_user " + eElement.getElementsByTagName("entry_date").item(0).getTextContent()) ;
						logger.info(" unique_id " + eElement.getElementsByTagName("unique_id").item(0).getTextContent() );
						logger.info(" first_touched_user " + eElement.getElementsByTagName("first_touched_user").item(0).getTextContent());
						logger.info(" underwriter_name " + eElement.getElementsByTagName("underwriter_name").item(0).getTextContent());

				
						fSB_WorkflowLocatorClient.getDataResponse(eElement.getElementsByTagName("loan_num").item(0).getTextContent(),
								eElement.getElementsByTagName("process_type").item(0).getTextContent(),
								eElement.getElementsByTagName("event").item(0).getTextContent(),
								eElement.getElementsByTagName("entry_date").item(0).getTextContent(),
								eElement.getElementsByTagName("entry_date").item(0).getTextContent(),
								eElement.getElementsByTagName("unique_id").item(0).getTextContent(),
								eElement.getElementsByTagName("first_touched_user").item(0).getTextContent(),
								eElement.getElementsByTagName("underwriter_name").item(0).getTextContent());
						
											
						
					}
				}
			
			    } catch (Exception e) {
			    	logger.error(e.toString());
			    }
		 

	}

}

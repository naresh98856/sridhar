package com.flagstarbank.fsb.ecm.loan.status.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.flagstarbank.fsb.ecm.loan.status.model.Event;
import com.flagstarbank.fsb.ecm.loan.status.model.VWFSBKOFAXFILENET;
import com.flagstarbank.fsb.ecm.loan.status.service.EventService;

@RestController
public class EventController {

	@Autowired
    EventService eventService;
	/*@Autowired
    EventService eventService;
	@RequestMapping(value="/event",method=RequestMethod.GET)
	public List<VWFSBKOFAXFILENET> getEventByID()
	{
		public Optional<VWFSBKOFAXFILENET> getEventId()
		 List<VWFSBKOFAXFILENET> event = eventService.getEventId();
		return event;
	}
*/
	
	@RequestMapping(value = "/event", method = RequestMethod.GET)
	public VWFSBKOFAXFILENET getEventById() throws Exception {
		System.out.println(this.getClass().getSimpleName() + " - Get employee details by id is invoked.");

		Optional<VWFSBKOFAXFILENET> emp = eventService.getEventId();
		/*if (!emp.isPresent())
			throw new Exception("Could not find employee with id- " + id);*/
		System.out.println("the data----------->"+emp);
		return emp.get();
	}

}

package com.flagstarbank.fsb.ecm.loan.status.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.flagstarbank.fsb.ecm.loan.status.dao.EventRepository;
import com.flagstarbank.fsb.ecm.loan.status.model.Event;
import com.flagstarbank.fsb.ecm.loan.status.model.VWFSBKOFAXFILENET;
import com.flagstarbank.fsb.ecm.loan.status.util.AppProperties;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	EventRepository eventRepository;
	
	
	public Optional<VWFSBKOFAXFILENET> getEventId()
	{
		/*AppProperties ap = new AppProperties();	
		String env_dev=ap.fetchProperties().getProperty("active.mq.url");
		RestTemplate restTemplate = new RestTemplate();
		Event event = restTemplate.getForObject(env_dev, Event.class);*/
		System.out.println("The event repo-------> start");
		//List<VWFSBKOFAXFILENET> e =eventRepository.getEventId("080263361"); 
				//findById("080263361");
		Optional<VWFSBKOFAXFILENET> event = eventRepository.findById("080263361");
		System.out.println("The event repo------->"+event);
		if(event.get().getIUC_FLAG()=="N" && event.get().getUW_READY_FLAG()=="Y")
			System.out.println("soap call 1");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="Y" && event.get().getCONDITION_TYPE()=="U")
			System.out.println("soap call 2");
		else if(event.get().getIUC_FLAG()=="N" && event.get().getUW_READY_FLAG()=="N")
			System.out.println("soap call 3");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="N" && event.get().getCONDITION_TYPE()=="U")
			System.out.println("soap call 4");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="Y" && event.get().getCONDITION_TYPE()=="P")
			System.out.println("soap call 5");
		else if(event.get().getIUC_FLAG()=="Y" && event.get().getUW_READY_FLAG()=="N" && event.get().getCONDITION_TYPE()=="P")
			System.out.println("soap call 6");
		return event;
	}
}

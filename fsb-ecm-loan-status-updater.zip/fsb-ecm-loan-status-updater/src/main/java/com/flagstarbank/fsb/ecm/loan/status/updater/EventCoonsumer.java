package com.flagstarbank.fsb.ecm.loan.status.updater;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.flagstarbank.fsb.ecm.loan.status.dao.EventRepository;
import com.flagstarbank.fsb.ecm.loan.status.model.Event;
import com.flagstarbank.fsb.ecm.loan.status.util.AppProperties;


public class EventCoonsumer {
	
	
	public String getLoanNumber()
	{
		AppProperties ap = new AppProperties();	
		String env_dev=ap.fetchProperties().getProperty("active.mq.url");
		RestTemplate restTemplate = new RestTemplate();
		Event event = restTemplate.getForObject(env_dev, Event.class);
		return event.getLoanNumber();
		
	}
	
	
}

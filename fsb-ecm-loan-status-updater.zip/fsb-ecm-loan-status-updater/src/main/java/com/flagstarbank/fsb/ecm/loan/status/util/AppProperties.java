package com.flagstarbank.fsb.ecm.loan.status.util;

import java.io.File;
import java.io.FileReader;
import java.net.URL;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class AppProperties {

	 public  Properties fetchProperties(){
			final Logger logger =LoggerFactory.getLogger(AppProperties.class.getName());
	        Properties properties = new Properties();
	        
	        try {
	        	//properties.load(this.getClass().getResourceAsStream("application.properties"));
	        	 ClassLoader classLoader = getClass().getClassLoader();
	            URL resource = classLoader.getResource("application.properties");
	            properties.load(new FileReader(new File(resource.getFile())));
	          
	        } catch (Exception e) {
	        logger.info("Exception", e);
	        }
	        return properties;
	 }
	 
}

package com.flagstarbank.fsb.ecm.loan.status.dao;

import java.util.List;

import javax.persistence.Column;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.flagstarbank.fsb.ecm.loan.status.model.VWFSBKOFAXFILENET;
//@Transactional
public interface EventRepository extends JpaRepository<VWFSBKOFAXFILENET,String>{
	/*
	@Query(value="SELECT loan_num,status,LOAN_TYPE,IUC_FLAG,UW_READY_FLAG,"
			+ "CONDITION_TYPE,DISSCO_STATUS FROM"
			+ " BRAVURA.VW_FSB_KOFAX_FILENET v WHERE v.loan_num=:loanNum", nativeQuery = true)
	public List<VWFSBKOFAXFILENET> getEventId(@Param("loanNum")String loan_num);*/

}

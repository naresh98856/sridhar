package com.flagstarbank.fsb.ecm.loan.status.soap;

public interface LoanStatusInterfaceEndpoint extends java.rmi.Remote {
    public java.lang.String updateDelUWStatus(java.lang.String string_1) throws java.rmi.RemoteException;
    public java.lang.String updateHudReviewStatus(java.lang.String string_1) throws java.rmi.RemoteException;
    public java.lang.String updatePostClosingStatus(java.lang.String string_1) throws java.rmi.RemoteException;
    public java.lang.String updateStatus(java.lang.String string_1) throws java.rmi.RemoteException;
}
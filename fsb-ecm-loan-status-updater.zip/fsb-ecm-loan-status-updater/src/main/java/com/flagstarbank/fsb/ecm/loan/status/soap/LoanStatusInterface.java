package com.flagstarbank.fsb.ecm.loan.status.soap;

public interface LoanStatusInterface  extends javax.xml.rpc.Service {
	 public java.lang.String getLoanStatusInterfaceEndpointPortAddress();

	    public com.flagstarbank.fsb.ecm.loan.status.soap.LoanStatusInterfaceEndpoint getLoanStatusInterfaceEndpointPort() throws javax.xml.rpc.ServiceException;

	    public com.flagstarbank.fsb.ecm.loan.status.soap.LoanStatusInterfaceEndpoint getLoanStatusInterfaceEndpointPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;

}

package com.flagstarbank.fsb.ecm.loan.status.updater;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.flagstarbank.fsb.ecm.loan.status.service.EventService;
import com.flagstarbank.fsb.ecm.loan.status.service.EventServiceImpl;

@SpringBootApplication
public class FsbEcmLoanStatusUpdaterApplication extends SpringBootServletInitializer {
 
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(FsbEcmLoanStatusUpdaterApplication.class);
        
    }
    
    

	public static void main(String[] args) {
		
		SpringApplication.run(FsbEcmLoanStatusUpdaterApplication.class, args);
		
			}


}

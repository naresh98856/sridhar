/**
 * 
 */
package com.flagstarbank.fsb.ecm.loan.status.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.springframework.stereotype.Component;

@Component

//Spring jpa jars.
@Entity
@Table(name= "vw_fsb_kofax_filenet")

//To increase speed and save sql statement execution time.
@DynamicInsert
@DynamicUpdate
public class VWFSBKOFAXFILENET {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)	
	  private String loan_num;
	  private String status;
	  private String LOAN_TYPE;
	  private String IUC_FLAG;
	  private String UW_READY_FLAG;
	  private String CONDITION_TYPE;
	 // private String  DISSCO_STATUS;
	public String getLoan_num() {
		return loan_num;
	}
	public void setLoan_num(String loan_num) {
		this.loan_num = loan_num;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getLOAN_TYPE() {
		return LOAN_TYPE;
	}
	public void setLOAN_TYPE(String lOAN_TYPE) {
		LOAN_TYPE = lOAN_TYPE;
	}
	public String getIUC_FLAG() {
		return IUC_FLAG;
	}
	public void setIUC_FLAG(String iUC_FLAG) {
		IUC_FLAG = iUC_FLAG;
	}
	public String getUW_READY_FLAG() {
		return UW_READY_FLAG;
	}
	public void setUW_READY_FLAG(String uW_READY_FLAG) {
		UW_READY_FLAG = uW_READY_FLAG;
	}
	public String getCONDITION_TYPE() {
		return CONDITION_TYPE;
	}
	public void setCONDITION_TYPE(String cONDITION_TYPE) {
		CONDITION_TYPE = cONDITION_TYPE;
	}
	/*
	 * public String getDISSCO_STATUS() { return DISSCO_STATUS; } public void
	 * setDISSCO_STATUS(String dISSCO_STATUS) { DISSCO_STATUS = dISSCO_STATUS; }
	 */
	  
	  
}

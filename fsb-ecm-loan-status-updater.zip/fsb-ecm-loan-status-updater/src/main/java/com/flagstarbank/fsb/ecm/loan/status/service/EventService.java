package com.flagstarbank.fsb.ecm.loan.status.service;

import java.util.List;
import java.util.Optional;

import com.flagstarbank.fsb.ecm.loan.status.model.VWFSBKOFAXFILENET;

public interface EventService {

	public Optional<VWFSBKOFAXFILENET> getEventId();
}

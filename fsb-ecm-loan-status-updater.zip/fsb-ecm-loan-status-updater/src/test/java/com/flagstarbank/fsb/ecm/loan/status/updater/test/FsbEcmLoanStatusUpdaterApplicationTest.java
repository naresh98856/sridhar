package com.flagstarbank.fsb.ecm.loan.status.updater.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.flagstarbank.fsb.ecm.loan.status.updater.FsbEcmLoanStatusUpdaterApplication;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FsbEcmLoanStatusUpdaterApplicationTest {

@Test  
public void whenInitiated_StartApplication() {
		FsbEcmLoanStatusUpdaterApplication.main(new String[] {});
	}

}

package com.flagstarbank.fsb.ecm.loan.status.rest.service;

import java.util.List;
import java.util.Optional;

import com.flagstarbank.fsb.ecm.loan.status.rest.model.Employee;
import com.flagstarbank.fsb.ecm.loan.status.rest.model.VWFSBKOFAXFILENET;

public interface Myservice {

	public List<Employee> getEmployees();
	public Optional<VWFSBKOFAXFILENET> getEmployeeById(String empid);
	public Employee addNewEmployee(Employee emp);
	public Employee updateEmployee(Employee emp);
	public void deleteEmployeeById(int empid);
	public void deleteAllEmployees();

}
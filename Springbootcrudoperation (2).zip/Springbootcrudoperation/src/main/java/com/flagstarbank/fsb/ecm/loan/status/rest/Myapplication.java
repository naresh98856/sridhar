package com.flagstarbank.fsb.ecm.loan.status.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

import com.flagstarbank.fsb.ecm.loan.status.rest.service.Myservice;
import com.flagstarbank.fsb.ecm.loan.status.rest.service.Myserviceimpl;


@SpringBootApplication
public class Myapplication {
	
	
	


	public static void main(String[] args) {
		SpringApplication.run(Myapplication.class, args);
		ReadxmlData readxmlData = new ReadxmlData();
		readxmlData.readXml();
		
		
	}
}
/**
 * LoanStatusInterfaceEndpoint.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flagstar.mortrac.webservice.LoanStatusInterface;

public interface LoanStatusInterfaceEndpoint extends java.rmi.Remote {
    public java.lang.String updateDelUWStatus(java.lang.String string_1) throws java.rmi.RemoteException;
    public java.lang.String updateHudReviewStatus(java.lang.String string_1) throws java.rmi.RemoteException;
    public java.lang.String updatePostClosingStatus(java.lang.String string_1) throws java.rmi.RemoteException;
    public java.lang.String updateStatus(java.lang.String string_1) throws java.rmi.RemoteException;
}

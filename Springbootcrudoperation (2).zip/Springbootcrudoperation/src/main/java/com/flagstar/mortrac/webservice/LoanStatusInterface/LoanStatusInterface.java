/**
 * LoanStatusInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.flagstar.mortrac.webservice.LoanStatusInterface;

public interface LoanStatusInterface extends javax.xml.rpc.Service {

	public java.lang.String getLoanStatusInterfaceEndpointPortAddress();

    public com.flagstar.mortrac.webservice.LoanStatusInterface.LoanStatusInterfaceEndpoint getLoanStatusInterfaceEndpointPort() throws javax.xml.rpc.ServiceException;

    public com.flagstar.mortrac.webservice.LoanStatusInterface.LoanStatusInterfaceEndpoint getLoanStatusInterfaceEndpointPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

package com.flagstar.mortrac.webservice.LoanStatusInterface;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceWrapper {
	
	private static final Logger logger = LoggerFactory.getLogger(ServiceWrapper.class.getName());
	FSB_CreateWorkitemSoapBindingStub  stub;
	
	public ServiceWrapper(){

	try
	{
		FSB_WSDL_WorkflowLocator locator = new 							
				FSB_WSDL_WorkflowLocator();
		
		stub = (FSB_CreateWorkitemSoapBindingStub)locator.getFSB_CreateWorkitemSoapPort();
	}
	catch (ServiceException afe)
	{
		logger.info("Service Exception",afe);
		
	}
}

	public String callUpdateService(String loanNum,String newStatus,String user) throws RemoteException
	{
		String requestBody="<request xmlns=\"http://com/fsb/module\">\r\n" + 
				"\r\n" + 
				"    <loanNumber>'"+loanNum+"'</loanNumber>\r\n" + 
				"\r\n" + 
				"    <newStatus>'"+newStatus+"'</newStatus>\r\n" + 
				"\r\n" + 
				"    <user>'"+user+"'</user>\r\n" + 
				"\r\n" + 
				"</request>\r\n" + 
				"";
	
	javax.xml.rpc.holders.StringHolder strXMLWorkitemData=new javax.xml.rpc.holders.StringHolder();
	strXMLWorkitemData.value=requestBody;
	
	 String retVal = null;
	retVal =  stub.updateWebservice(strXMLWorkitemData);
	logger.info("The soap result->"+retVal);
	
	return retVal;
	
}

}